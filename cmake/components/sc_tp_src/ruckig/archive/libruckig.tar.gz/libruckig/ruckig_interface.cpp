﻿#include "ruckig_interface.h"

//! Example RUCKIG r;
//!
//! Implementations:
//!     1.  Waypoints with velocity end.
//!     2.  Master machine velocity control.
//!     3.  Feed overide  0 to 100%
//!     4.  Adaptive feed -100% to 100%
//!     5.  Controlled machine stop.
//!     6.  Absolute or relative position input.
//!
#define to_override ((r.maxvel_machine_overide/100)+1)
#define to_adaptive_feed (r.adaptive_feed*0.01)

//! Add waypoints.
int ruckig_interface::add_demo_waypoints(RUCKIG &r){

    r.maxvel_machine=200;
    r.maxacc_machine=150;
    r.maxjerk_machine=100;
    r.maxvel_machine_overide=0;

    WAYPOINT wp;
    std::vector<WAYPOINT> wpvec;
    if(r.demo){
        double maxvel=200;
        double maxacc=100;
        double maxjerk=50;
        //! (maxvel,maxacc,maxjerk,startpos,endpos,startvel,endvel,pathlenght=0)
        wpvec.push_back({maxvel,maxacc,maxjerk,0,10,0,0,0,0});
        wpvec.push_back({maxvel,maxacc,maxjerk,10,5000,0,0,5,0});       //! startpos:10, endpos:50
        wpvec.push_back({maxvel,maxacc,maxjerk,5000,130,0,5,0,0});      //! using endvel:5.
        wpvec.push_back({maxvel,maxacc,maxjerk,130,200,0,0,0,0});       //! using startvel:5.
        wpvec.push_back({maxvel,maxacc,maxjerk,200,-20,0,0,0,0});
        wpvec.push_back({maxvel,maxacc,maxjerk,-20, 0,0,0,0,0});

        //! Fill the ruckig waypointvec.
        std::cout<<""<<std::endl;
        for(unsigned int i=0; i<wpvec.size(); i++){
            //! Creates a relative input.
            if(i==0){ //! Startup loop
                wp.pathlenght=abs(wpvec.at(i).endpos-wpvec.at(i).startpos);
                wp.startpos=wpvec.at(i).startpos;
                wp.endpos=wp.startpos+wp.pathlenght;
            }
            if(i>0){
                wp.pathlenght=abs(wpvec.at(i).endpos-wpvec.at(i).startpos);
                wp.startpos=r.waypointvec.back().endpos;
                wp.endpos=r.waypointvec.back().endpos+wp.pathlenght;
            }
            wp.maxvel=wpvec.at(i).maxvel;
            wp.maxacc=wpvec.at(i).maxacc;
            wp.maxjerk=wpvec.at(i).maxjerk;
            wp.startvel=wpvec.at(i).startvel;
            wp.endvel=wpvec.at(i).endvel;
            r.waypointvec.push_back(wp);
            ;
            std::cout<<"wpvec at i:"<<i<<" startpos:"<<wp.startpos<<" endpos:"<<wp.endpos<<" pathlenght:"<<wp.pathlenght<<std::endl;
        }
    }
    return 1;
}

//! Current pathlenght & distancetogo in %. Can be used to interpolate xyz.
int ruckig_interface::distancetogo(RUCKIG &r){

    r.pathlenght=abs(r.waypointvec.at(r.i).endpos-r.waypointvec.at(r.i).startpos);
    r.dtg=abs(pos[0]-r.waypointvec.at(r.i).endpos);
    // std::cout<<"waypointvec at i:"<<r.i<<" pathlenght:"<<r.pathlenght<<std::endl;
    // std::cout<<"waypointvec at i:"<<r.i<<" dtg:"<<r.dtg<<std::endl;
    return 1;
}

//! Restart at a waypoint[r.i] position.
int ruckig_interface::restart_at_waypoint(RUCKIG &r){

    return 1;
}

//! Ruckig traject example
int ruckig_interface::ruckig_traject(RUCKIG &r){
    int ok=0;
    if(r.init==false){
        //! enum: position, velocity
        in.control_interface=ruckig::ControlInterface::Position;
        //! Phase, ///< Phase synchronize the DoFs when possible, else fallback to "Time" strategy
        //! Time, ///< Always synchronize the DoFs to reach the target at the same time (Default)
        //! TimeIfNecessary, ///< Synchronize only when necessary (e.g. for non-zero target velocity or acceleration)
        //! None, ///< Calculate every DoF independently
        in.synchronization=ruckig::Synchronization::None;
        //! Continuous, ///< Every trajectory duration is allowed (Default)
        //! Discrete, ///< The trajectory duration must be a multiple of the control cycle
        in.duration_discretization=ruckig::DurationDiscretization::Continuous;

        if(r.demo){
            ok=add_demo_waypoints(r);
            if(ok){std::cout<<"add demo waypoints ok"<<std::endl;}
        }

        //! Check if the waypointvec has values.
        if(r.waypointvec.size()<1){
            std::cout<<"empty waypointvec"<<std::endl;
        }
        r.init=true;
    }

    if(r.finished){
        r.i=0;
        vel[0]=0;
        acc[0]=0;
        pos[0]=r.waypointvec.at(r.i).startpos;
        r.tr_duration=0;
        // r.finished=0;
    }

    if(!r.finished){

        //! Set local path velocity. If the maxvel is negative, it is used later on. Ruckig input must be >0.
        in.max_velocity[0]=abs((r.waypointvec.at(r.i).maxvel*abs(to_override))*to_adaptive_feed); //for test: abs(r.maxvel_machine);

        //! Limit local path velocity to maximum machine velocity.
        if(in.max_velocity[0]>r.maxvel_machine*abs(to_override)){
            in.max_velocity[0]=abs(r.maxvel_machine*abs(to_override));
        }
        if(in.max_velocity[0]==0){in.max_velocity[0]=0.001;}

        in.max_acceleration[0]=r.waypointvec.at(r.i).maxacc;
        if(in.max_acceleration[0]==0){in.max_acceleration[0]=0.001;}

        in.max_jerk[0]=r.waypointvec.at(r.i).maxjerk;
        if(in.max_jerk[0]==0){in.max_jerk[0]=0.001;}

        if(r.maxvel_machine>0){
            in.target_position[0]=r.waypointvec.at(r.i).endpos;
            in.target_velocity[0]=r.waypointvec.at(r.i).endvel;
        }
        if(r.maxvel_machine<0 && r.i>0){
            in.target_position[0]=r.waypointvec.at(r.i).startpos;
            in.target_velocity[0]=r.waypointvec.at(r.i-1).endvel;
        }

        //! Motion stop request. We take a snapshot and go back to this position. Controlled stop with vel=0.001 will result in error.
        //! This is the workaround. Another solution is to calculate stop distance and perform a stop path. On the other hand if tool
        //! is broken, machine is exact at stop request.
        if(r.motion_stop){
            if(!r.motion_stop_snapshot){
                r.snapshot_pos=pos[0];
                r.motion_stop_snapshot=1;
            }
            in.target_position[0]=r.snapshot_pos;
        } else {
            r.motion_stop_snapshot=0;
        }

        in.target_acceleration[0]=0;
        in.current_velocity[0]=vel[0];
        in.current_acceleration[0]=acc[0];
        in.current_position[0]=pos[0];

        distancetogo(r);
        // velocity_limits(r);

        result=otg.update(in, out);
        //! Return eventual errors.
        if(result==ruckig::Error){ ///< Unclassified error
            //return -1;
        }
        if(result==ruckig::ErrorInvalidInput){ //! -100, ///< Error in the input parameter
            //return -100;
        }
        if(result==ruckig::ErrorTrajectoryDuration){ //! -101, ///< The trajectory duration exceeds its numerical limits
            //return -101;
        }
        if(result==ruckig::ErrorPositionalLimits){ //! -102, ///< The trajectory exceeds the given positional limits (only in Ruckig Pro)
            //return -102;
        }
        if(result==ruckig::ErrorExecutionTimeCalculation){ //! -110, ///< Error during the extremel time calculation (Step 1)
            //return -110;
        }
        if(result==ruckig::ErrorSynchronizationCalculation){ //! -111, ///< Error during the synchronization calculation (Step 2)
            //return -111;
        }

        out.trajectory.at_time(0.001,pos, vel, acc);
        //! Traject duration.
        r.tr_duration+=0.001;
        //! Current path duration.
        r.waypointvec.at(r.i).wp_duration+=0.001;
        //! Terminal output msg reducer.
        r.msg+=0.001;

        r.at_start=0; r.at_finish=0;

        //! Machine Master velocity>0, Ruckig problably using endvelocity.
        if(pos[0]>r.waypointvec.at(r.i).endpos && r.waypointvec.at(r.i).startpos<r.waypointvec.at(r.i).endpos && r.maxvel_machine>0){
            std::cout<<"Msg.0 waypointvec i:"<<r.i<<" pos:"<<pos[0]<<" vel:"<<vel[0]<<" acc:"<<acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
            //! Using positive machine velocity.
            if(r.i<r.waypointvec.size()-1){r.i++;}
        } else //! Without else it could count r.i 2 times up.
            //! 1. Ruckig waypoint finished, makes error with motion stop command, replaced with position reached trigger.
            if(result==ruckig::Finished  && r.maxvel_machine>0){
                std::cout<<"Msg.1 waypointvec i:"<<r.i<<" pos:"<<pos[0]<<" vel:"<<vel[0]<<" acc:"<<acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
                if(r.i<r.waypointvec.size()-1 && r.maxvel_machine>0){r.i++;}
            } else

                //! Machine Master velocity<0, Ruckig problably using endvelocity.
                if(pos[0]<r.waypointvec.at(r.i).startpos && r.waypointvec.at(r.i).startpos<r.waypointvec.at(r.i).endpos && r.maxvel_machine<0){
                    std::cout<<"Msg.2 waypointvec i:"<<r.i<<" pos:"<<pos[0]<<" vel:"<<vel[0]<<" acc:"<<acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
                    //! Using positive machine velocity.
                    if(r.i>0){r.i--;}
                } else //! Without else it could count r.i 2 times up.
                    //! Ruckig waypoint finished.
                    if(result==ruckig::Finished && r.maxvel_machine<0){
                        std::cout<<"Msg.3 waypointvec i:"<<r.i<<" pos:"<<pos[0]<<" vel:"<<vel[0]<<" acc:"<<acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
                        if(r.i>0){r.i--;}
                    } else

                        //! Final traject position reached.
                        if(r.i==r.waypointvec.size()-1 && pos[0]==r.waypointvec.at(r.i).endpos){
                            r.at_finish=1;
                            r.finished=1;
                        } else

                            //! Begin traject position reached, problably with reverse machine velocity.
                            if(pos[0]==r.waypointvec.at(r.i).startpos && r.maxvel_machine<0){
                                r.at_start=1;
                            }

        if(r.msg>0.1){
            std::cout<<"waypointvec i:"<<r.i<<"pos:"<<pos[0]<<"vel:"<<vel[0]<<" acc:"<<acc[0]<<std::endl;

            if(r.at_finish){
                std::cout<<"at_finish"<<std::endl;
            }
            if(r.at_start){
                std::cout<<"at_start"<<std::endl;
            }

            r.msg=0;
        }
    }

    return 1;
}

//! Example using velocity end, online mode
void ruckig_interface::ruckig_example_0(){

    //! Used by gcode planner.
    ruckig::Ruckig<1> otg2 {0.001};
    ruckig::Trajectory<1> trajectory2;
    ruckig::InputParameter<1> in2;
    ruckig::OutputParameter<1> out2;
    std::array<double, 1> vel2, acc2, pos2;

    in2.max_velocity[0]=25;
    in2.max_acceleration[0]=5;
    in2.max_jerk[0]=4;

    in2.current_velocity[0]=0;
    in2.current_acceleration[0]=0;
    in2.current_position[0]=0;

    in2.target_position[0]=50;
    in2.target_velocity[0]=10;
    in2.target_acceleration[0]=0;

    //! enum: position, velocity
    in2.control_interface=ruckig::ControlInterface::Position;
    //! Phase, ///< Phase synchronize the DoFs when possible, else fallback to "Time" strategy
    //! Time, ///< Always synchronize the DoFs to reach the target at the same time (Default)
    //! TimeIfNecessary, ///< Synchronize only when necessary (e.g. for non-zero target velocity or acceleration)
    //! None, ///< Calculate every DoF independently
    in2.synchronization=ruckig::Synchronization::None;
    //! Continuous, ///< Every trajectory duration is allowed (Default)
    //! Discrete, ///< The trajectory duration must be a multiple of the control cycle
    in2.duration_discretization=ruckig::DurationDiscretization::Continuous;

    auto result_x=otg2.update(in2,out2);
    std::cout<<"ruckig message"<<result_x<<std::endl;

    for(double i=0; i<out2.trajectory.get_duration()+0.001; i+=0.001){

        out2.trajectory.at_time(i,pos2, vel2, acc2);
        //! Result
        std::cout<<"online mode"<<std::endl;
        std::cout<<"pos"<<pos2[0]<<std::endl;
        std::cout<<"vel"<<vel2[0]<<std::endl;
        std::cout<<"acc"<<acc2[0]<<std::endl;
    }
}

//! Example using velocity end, offline mode
void ruckig_interface::ruckig_example_1(){

    //! Used by gcode planner.
    ruckig::Ruckig<1> otg2;
    ruckig::Trajectory<1> trajectory2;
    ruckig::InputParameter<1> in2;
    ruckig::OutputParameter<1> out2;
    std::array<double, 1> vel2, acc2, pos2;

    in2.max_velocity[0]=25;
    in2.max_acceleration[0]=5;
    in2.max_jerk[0]=4;

    in2.current_velocity[0]=0;
    in2.current_acceleration[0]=0;
    in2.current_position[0]=0;

    in2.target_position[0]=50;
    in2.target_velocity[0]=10;
    in2.target_acceleration[0]=0;

    //! enum: position, velocity
    in2.control_interface=ruckig::ControlInterface::Position;
    //! Phase, ///< Phase synchronize the DoFs when possible, else fallback to "Time" strategy
    //! Time, ///< Always synchronize the DoFs to reach the target at the same time (Default)
    //! TimeIfNecessary, ///< Synchronize only when necessary (e.g. for non-zero target velocity or acceleration)
    //! None, ///< Calculate every DoF independently
    in2.synchronization=ruckig::Synchronization::None;
    //! Continuous, ///< Every trajectory duration is allowed (Default)
    //! Discrete, ///< The trajectory duration must be a multiple of the control cycle
    in2.duration_discretization=ruckig::DurationDiscretization::Continuous;

    auto result_x=otg2.update(in2,out2);
    std::cout<<"ruckig message"<<result_x<<std::endl;

    for(double i=0; i<trajectory2.get_duration()+0.001; i+=0.001){

        out2.trajectory.at_time(i,pos2, vel2, acc2);
        //! Result
        std::cout<<"offline mode"<<std::endl;
        std::cout<<"pos"<<pos2[0]<<std::endl;
        std::cout<<"vel"<<vel2[0]<<std::endl;
        std::cout<<"acc"<<acc2[0]<<std::endl;

        in2.current_velocity[0]=vel2[0];
        in2.current_acceleration[0]=acc2[0];
        in2.current_position[0]=pos2[0];
    }
}

//! For gcode path planner. We have to know how long is our stop distance when using maxvel/curvel.
//! We have to check at wich path we have to start slowing down to stop at correct endpoint.
double ruckig_interface::get_stop_distance(double curpos,double curvel,double curacc, double tarvel, double taracc, double maxacc, double maxjerk){

    in1.control_interface = ruckig::ControlInterface::Velocity;

    in1.current_position = {curpos};
    in1.current_velocity = {curvel};
    in1.current_acceleration = {curacc};

    in1.target_velocity = {tarvel};
    in1.target_acceleration = {taracc};

    in1.max_acceleration = {maxacc};
    in1.max_jerk = {maxjerk};

    auto result_x=otg1.update(in1, out1);
    if(result_x==ruckig::Result::Finished){
        // std::cout<<"ruckig finished"<<result_x<<std::endl;
    }

    std::cout << "Trajectory duration: " << out1.trajectory.get_duration() << " [s]." << std::endl;
    out1.trajectory.at_time(out1.trajectory.get_duration() ,pos1,vel1,acc1);

    return pos1[0];
}

//! Calculate at wich velocity and acceleration the current motion will leave the current gcodeblock.
std::pair<double,double> ruckig_interface::get_target_velocity_acceleration(double at_time, double curpos, double curvel, double curacc, double maxvel, double maxacc, double maxjerk){

    std::pair<double,double> pair;

    in1.control_interface = ruckig::ControlInterface::Position;

    in1.current_position[0] = curpos;
    in1.current_velocity[0] = curvel;
    in1.current_acceleration[0] = curacc;

    in1.target_position[0] = 1000000000; //! A infinite number that normally is not reached.
    in1.target_velocity[0]=maxvel;
    in1.target_acceleration[0]=0;

    in1.max_velocity[0] = maxvel;
    in1.max_acceleration[0] = maxacc;
    in1.max_jerk[0] = maxjerk;

    auto result_x=otg1.update(in1, out1);
    if(result_x==ruckig::Result::Finished){
        // std::cout<<"ruckig finished"<<result_x<<std::endl;
    }

    //std::cout << "Trajectory duration: " << out1.trajectory.get_duration() << " [s]." << std::endl;
    out1.trajectory.at_time(at_time ,pos1,vel1,acc1);

    pair.first=vel1[0];
    pair.second=acc1[0];

    //std::cout << "target vel" << vel1[0] << std::endl;
    //std::cout << "target acc" << acc1[0] << std::endl;

    return pair;
}

//! High level c++ lib reqeust from halmodule.c
extern "C" DATA rm_fk(struct DATA *ptr){
    DATA ptr_result=ruckig_interface().rm_fk(ptr);
    return ptr_result;
}

extern "C" DATA rm_ik(struct DATA *ptr){
    DATA ptr_result=ruckig_interface().rm_ik(ptr);
    return ptr_result;
}

//! Ruckig s-curve motion used by halmodule.c
DATA ruckig_interface::rm_ik(DATA *ptr){

    //! abs_cart,abs_euler,rel_cart,rel_euler are offline values.
    for(unsigned int i=0; i<ptr->machines; i++){
        //! 3d, cartxyz, eulerxyz
        for(int j=0; j<6; j++){
            int id=0;
            in0.enabled[id]=1;
            if(j<3){
                in0.max_velocity[id]=ptr->machine[i].maxvel_cart;
                in0.max_acceleration[id]=ptr->machine[i].maxacc_cart;
                in0.max_jerk[id]=ptr->machine[i].jerk_cart;
            } else {
                in0.max_velocity[id]=ptr->machine[i].maxvel_euler;
                in0.max_acceleration[id]=ptr->machine[i].maxacc_euler;
                in0.max_jerk[id]=ptr->machine[i].jerk_euler;

            }
            in0.current_velocity[id]=ptr->machine[i].ruckig_curvel_cart_euler[j];
            in0.current_acceleration[id]=ptr->machine[i].ruckig_curacc_cart_euler[j];
            in0.current_position[id]=ptr->machine[i].ruckig_curpos_cart_euler[j];

            if(j==0){
                in0.target_position[id]=ptr->machine[i].abs_cart.x;
            }
            if(j==1){
                in0.target_position[id]=ptr->machine[i].abs_cart.y;
            }
            if(j==2){
                in0.target_position[id]=ptr->machine[i].abs_cart.z;
            }
            if(j==3){
                in0.target_position[id]=ptr->machine[i].abs_euler.x;
            }
            if(j==4){
                in0.target_position[id]=ptr->machine[i].abs_euler.y;
            }
            if(j==5){
                in0.target_position[id]=ptr->machine[i].abs_euler.z;
            }

            //! Todo: this values can be used when the gcode intepreter can predict this values by a look-ahead function.
            in0.target_velocity[id]=0;
            in0.target_acceleration[id]=0;


            //! enum: position, velocity
            in0.control_interface=ruckig::ControlInterface::Position;
            //! Phase, ///< Phase synchronize the DoFs when possible, else fallback to "Time" strategy
            //! Time, ///< Always synchronize the DoFs to reach the target at the same time (Default)
            //! TimeIfNecessary, ///< Synchronize only when necessary (e.g. for non-zero target velocity or acceleration)
            //! None, ///< Calculate every DoF independently
            in0.synchronization=ruckig::Synchronization::None;
            //! Continuous, ///< Every trajectory duration is allowed (Default)
            //! Discrete, ///< The trajectory duration must be a multiple of the control cycle
            in0.duration_discretization=ruckig::DurationDiscretization::Continuous;

            auto result_x=otg0.update(in0,out0);
            if(result_x==ruckig::Result::Finished){
                // std::cout<<"ruckig finished"<<result_x<<std::endl;
            }
            out0.trajectory.at_time(0.001,pos0, vel0, acc0);

            //! Update hal.
            ptr->machine[i].ruckig_curpos_cart_euler[j]=pos0[id];
            ptr->machine[i].ruckig_curvel_cart_euler[j]=vel0[id];
            ptr->machine[i].ruckig_curacc_cart_euler[j]=acc0[id];

            //std::cout<<"ruckig pos cart:"<< ptr->machine[i].ruckig_curpos_cart_euler[j]<<std::endl;
        }
    }
    return *ptr;
}

//! Ruckig s-curve motion used by halmodule.c
DATA ruckig_interface::rm_fk(DATA *ptr){
    //! Calculate synchronized motion for every joint.
    for(unsigned int i=0; i<ptr->machines; i++){
        for(unsigned int j=0; j<ptr->machine[i].joints; j++){
            int id=0;
            in0.enabled[id]=1;
            in0.max_velocity[id]=ptr->machine[i].joint[j].maxvel;
            in0.max_acceleration[id]=ptr->machine[i].joint[j].maxacc;
            in0.max_jerk[id]=ptr->machine[i].joint[j].jerk;
            //! enum: position, velocity
            in0.control_interface=ruckig::ControlInterface::Position;
            //! Phase, ///< Phase synchronize the DoFs when possible, else fallback to "Time" strategy
            //! Time, ///< Always synchronize the DoFs to reach the target at the same time (Default)
            //! TimeIfNecessary, ///< Synchronize only when necessary (e.g. for non-zero target velocity or acceleration)
            //! None, ///< Calculate every DoF independently
            in0.synchronization=ruckig::Synchronization::None;
            //! Continuous, ///< Every trajectory duration is allowed (Default)
            //! Discrete, ///< The trajectory duration must be a multiple of the control cycle
            in0.duration_discretization=ruckig::DurationDiscretization::Continuous;

            in0.current_position[id]=ptr->machine[i].joint[j].curpos_ruckig;
            in0.current_velocity[id]=ptr->machine[i].joint[j].curvel;
            in0.current_acceleration[id]=ptr->machine[i].joint[j].curacc;

            in0.target_position[id]=ptr->machine[i].joint[j].curpos_abs;
            //! This values can be used when the gcode intepreter can predict this values by a look-ahead function.
            in0.target_velocity[id]=0;
            in0.target_acceleration[id]=0;

            auto result_x=otg0.update(in0,out0);
            if(result_x==ruckig::Result::Finished){
                // std::cout<<"ruckig finished"<<result_x<<std::endl;
            }
            out0.trajectory.at_time(0.001,pos0, vel0, acc0);

            //! Update hal.
            ptr->machine[i].joint[j].curpos_ruckig=pos0[id];
            ptr->machine[i].joint[j].curvel=vel0[id];
            ptr->machine[i].joint[j].curacc=acc0[id];

            // std::cout<<"ruckig curpos:"<< ptr->machine[i].joint[j].curpos_ruckig<<std::endl;
        }
    }
    return *ptr;
}

ruckig_interface::ruckig_interface()
{

}

