#ifndef RUCKIG_TRAJECT_H
#define RUCKIG_TRAJECT_H

#define to_override ((r.feed_overide/100)+1)
#define time_interval 0.01

//! LibRuckig scurve lib
//! https://github.com/pantor/ruckig, extra info: https://github.com/pantor/ruckig/issues/64
//! Examples
//! https://docs.ruckig.com/pages.html
#include "libruckig/include/ruckig/ruckig.hpp"

class ruckig_traject
{
public:
    ruckig_traject();

    //! Waypoint, (maxvel,maxacc,maxjerk,startpos,endpos,startvel,endvel,endacc)
    struct WAYPOINT{
        //! Maxvel.
        double maxvel=0;
        //! Maxacc.
        double maxacc=0;
        //! Maxjerk.
        double maxjerk=0;
        //! Startpos.
        double startpos=0;
        //! Endpos.
        double endpos=0;
        //! Start velocity. Used as endvel for negative feed.
        double startvel=0;
        //! End velocity.
        double endvel=0;
        //! Pathlenght.
        double pathlenght=0;
        //! Waypoint duration.
        double wp_duration=0;
    };

    struct RUCKIG{
        //! Program status flags
        bool init=0;
        //! At path finish.
        bool at_finish=0;
        //! At path start.
        bool at_start=0;
        //! Start with demo values.
        bool demo=0;
        //! Waypoint counter.
        unsigned int i=0;

        //! Machine limits.
        double maxvel_machine=0;
        double maxacc_machine=0;
        double maxjerk_machine=0;
        //! Dofs velocity overide 20%.
        //! Velocity overide 0-20% may be a negative value.
        double feed_overide=0;

        //! Controlled stop.
        bool motion_stop;
        //! Stop position snapshot.
        bool motion_stop_snapshot;
        double snapshot_pos=0;

        //! Pathlenght[i].
        double pathlenght;
        //! Distancetogo[i].
        double dtg;
        //! Traject duration.
        double tr_duration=0;
        //! Traject finished.
        bool finished=0;
        //! Ruckig results.
        std::array<double, 1> vel, acc, pos;

        //! Waypoint vector
        std::vector<WAYPOINT> waypointvec;
    };

    int traject(RUCKIG &r);
    int add_demo_waypoints(RUCKIG &r);
    int distancetogo(RUCKIG &r);
    int restart_at_waypoint(RUCKIG &r);

    //! Ruckig data.
    ruckig::Result result;
    ruckig::Ruckig<1> otg {time_interval};
    ruckig::InputParameter<1> in;
    ruckig::OutputParameter<1> out;

};

#endif // RUCKIG_TRAJECT_H
