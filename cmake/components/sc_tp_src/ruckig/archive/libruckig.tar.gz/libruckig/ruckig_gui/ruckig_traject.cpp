#include "ruckig_traject.h"

ruckig_traject::ruckig_traject()
{

}

//! Add waypoints.
int ruckig_traject::add_demo_waypoints(RUCKIG &r){

    WAYPOINT wp, in;
    std::vector<WAYPOINT> wpvec;
    if(r.demo){
        //! a path.
        in.maxvel=10;
        in.maxacc=5;
        in.maxjerk=4;

        in.startpos=0;
        in.endpos=100;
        in.startvel=0;
        in.endvel=8;
        wpvec.push_back(in);

        in.startpos=100;
        in.endpos=-10;
        in.startvel=8;
        in.endvel=0;
        wpvec.push_back(in);

        in.startpos=-10;
        in.endpos=200;
        in.startvel=0;
        in.endvel=0;
        wpvec.push_back(in);

        in.startpos=200;
        in.endpos=250;
        in.startvel=0;
        in.endvel=0;
        wpvec.push_back(in);

        in.startpos=250;
        in.endpos=0;
        in.startvel=0;
        in.endvel=0;
        wpvec.push_back(in);


        //! Fill the ruckig waypointvec.
        std::cout<<""<<std::endl;
        for(unsigned int i=0; i<wpvec.size(); i++){
            //! Creates a relative input.
            if(i==0){ //! Startup loop
                wp.pathlenght=abs(wpvec.at(i).endpos-wpvec.at(i).startpos);
                wp.startpos=wpvec.at(i).startpos;
                wp.endpos=wp.startpos+wp.pathlenght;
            }
            if(i>0){
                wp.pathlenght=abs(wpvec.at(i).endpos-wpvec.at(i).startpos);
                wp.startpos=r.waypointvec.back().endpos;
                wp.endpos=r.waypointvec.back().endpos+wp.pathlenght;
            }
            wp.maxvel=wpvec.at(i).maxvel;
            wp.maxacc=wpvec.at(i).maxacc;
            wp.maxjerk=wpvec.at(i).maxjerk;
            wp.startvel=wpvec.at(i).startvel;
            wp.endvel=wpvec.at(i).endvel;
            r.waypointvec.push_back(wp);

            std::cout<<"wpvec at i:"<<i<<" startpos:"<<wp.startpos<<" endpos:"<<wp.endpos<<" pathlenght:"<<wp.pathlenght<<std::endl;
        }
    }
    return 1;
}

//! Current pathlenght & distancetogo in %. Can be used to interpolate xyz.
int ruckig_traject::distancetogo(RUCKIG &r){

    r.pathlenght=abs(r.waypointvec.at(r.i).endpos-r.waypointvec.at(r.i).startpos);
    r.dtg=abs(r.pos[0]-r.waypointvec.at(r.i).endpos);
    return 1;
}

//! Restart at a waypoint[r.i] position.
int ruckig_traject::restart_at_waypoint(RUCKIG &r){

    return 1;
}

//! Ruckig traject example.
//! Implementations:
//!     - Waypoints with velocity end.
//!     - Master machine velocity control.
//!     - Feed overide  0 to 100%.
//!     - Controlled machine stop.
//!
int ruckig_traject::traject(RUCKIG &r){
    std::cout.precision(3);
    int ok=0;
    if(r.init==false){
        if(r.demo){
            ok=add_demo_waypoints(r);
            if(ok){std::cout<<"add demo waypoints ok"<<std::endl;}
        }

        //! enum: position, velocity
        in.control_interface=ruckig::ControlInterface::Position;
        //! Phase, ///< Phase synchronize the DoFs when possible, else fallback to "Time" strategy
        //! Time, ///< Always synchronize the DoFs to reach the target at the same time (Default)
        //! TimeIfNecessary, ///< Synchronize only when necessary (e.g. for non-zero target velocity or acceleration)
        //! None, ///< Calculate every DoF independently
        in.synchronization=ruckig::Synchronization::None;
        //! Continuous, ///< Every trajectory duration is allowed (Default)
        //! Discrete, ///< The trajectory duration must be a multiple of the control cycle
        in.duration_discretization=ruckig::DurationDiscretization::Continuous;

        //! Check if the waypointvec has values.
        if(r.waypointvec.size()<1){
            std::cout<<"empty waypointvec"<<std::endl;
        }

        r.init=true;
    }

    if(r.finished){
        //r.i=0;
        //r.vel[0]=0;
        //r.acc[0]=0;
        //r.pos[0]=r.waypointvec.at(r.i).startpos;
        //r.tr_duration=0;
    }

    //! Set local path velocity. If the maxvel is negative, it is used later on. Ruckig input must be >0.
    in.max_velocity[0]=abs(r.waypointvec.at(r.i).maxvel*abs(to_override));

    //! Limit local path velocity to maximum machine velocity.
    if(in.max_velocity[0]>abs(r.maxvel_machine*abs(to_override))){
        in.max_velocity[0]=abs(r.maxvel_machine*abs(to_override));
    }

    if(in.max_velocity[0]==0){in.max_velocity[0]=0.001;}

    in.max_acceleration[0]=r.waypointvec.at(r.i).maxacc;
    if(in.max_acceleration[0]==0){in.max_acceleration[0]=0.001;}

    in.max_jerk[0]=r.waypointvec.at(r.i).maxjerk;
    if(in.max_jerk[0]==0){in.max_jerk[0]=0.001;}

    if(r.maxvel_machine>0){
        in.target_position[0]=r.waypointvec.at(r.i).endpos;
        in.target_velocity[0]=r.waypointvec.at(r.i).endvel;
    }
    if((r.maxvel_machine<0 && r.i>0)){
        in.target_position[0]=r.waypointvec.at(r.i).startpos;
        in.target_velocity[0]=r.waypointvec.at(r.i-1).endvel;
    }
    if((r.maxvel_machine<0 && r.i==0)){
        in.target_position[0]=r.waypointvec.at(r.i).startpos;
        in.target_velocity[0]=0;
        in.target_acceleration[0]=0;
    }

    //! Motion stop request. We take a snapshot and go back to this position. Controlled stop with vel=0.001 will result in error.
    //! This is the workaround. Another solution is to calculate stop distance and perform a stop path. On the other hand if tool
    //! is broken, machine is exact at stop request.
    if(r.motion_stop){
        if(!r.motion_stop_snapshot){
            r.snapshot_pos=r.pos[0];
            r.motion_stop_snapshot=1;
        }
        in.target_position[0]=r.snapshot_pos;
        in.target_velocity[0]=0;
        in.target_acceleration[0]=0;
    } else {
        r.motion_stop_snapshot=0;
    }

    in.target_acceleration[0]=0;
    in.current_velocity[0]=r.vel[0];
    in.current_acceleration[0]=r.acc[0];
    in.current_position[0]=r.pos[0];

    distancetogo(r);

    result=otg.update(in, out);
    //! Return eventual errors.
    if(result==ruckig::Error){ ///< Unclassified error
        //return -1;
    }
    if(result==ruckig::ErrorInvalidInput){ //! -100, ///< Error in the input parameter
        //return -100;
    }
    if(result==ruckig::ErrorTrajectoryDuration){ //! -101, ///< The trajectory duration exceeds its numerical limits
        //return -101;
    }
    if(result==ruckig::ErrorPositionalLimits){ //! -102, ///< The trajectory exceeds the given positional limits (only in Ruckig Pro)
        //return -102;
    }
    if(result==ruckig::ErrorExecutionTimeCalculation){ //! -110, ///< Error during the extremel time calculation (Step 1)
        //return -110;
    }
    if(result==ruckig::ErrorSynchronizationCalculation){ //! -111, ///< Error during the synchronization calculation (Step 2)
        //return -111;
    }

    out.trajectory.at_time(time_interval,r.pos, r.vel, r.acc);

    //! Traject duration.
    r.tr_duration+=time_interval;
    //! Current path duration.
    r.waypointvec.at(r.i).wp_duration+=time_interval;

    r.at_start=0; r.at_finish=0;

    //! Machine Master velocity>0, Ruckig problably using endvelocity.
    if(r.pos[0]>r.waypointvec.at(r.i).endpos && r.waypointvec.at(r.i).startpos<r.waypointvec.at(r.i).endpos && r.maxvel_machine>0){
        //std::cout<<"Msg.0 waypointvec i:"<<r.i<<" pos:"<<r.pos[0]<<" vel:"<<r.vel[0]<<" acc:"<<r.acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
        //! Using positive machine velocity.
        if(r.i<r.waypointvec.size()-1){r.i++;}
    } else //! Without else it could count r.i 2 times up.
        //! 1. Ruckig waypoint finished, makes error with motion stop command, replaced with position reached trigger.
        if(result==ruckig::Finished  && r.maxvel_machine>0){
            //std::cout<<"Msg.1 waypointvec i:"<<r.i<<" pos:"<<r.pos[0]<<" vel:"<<r.vel[0]<<" acc:"<<r.acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
            if(r.i<r.waypointvec.size()-1 && r.maxvel_machine>0){r.i++;}
        } else

            //! Machine Master velocity<0, Ruckig problably using endvelocity.
            if(r.pos[0]<r.waypointvec.at(r.i).startpos && r.waypointvec.at(r.i).startpos<r.waypointvec.at(r.i).endpos && r.maxvel_machine<0){
                //std::cout<<"Msg.2 waypointvec i:"<<r.i<<" pos:"<<r.pos[0]<<" vel:"<<r.vel[0]<<" acc:"<<r.acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
                //! Using positive machine velocity.
                if(r.i>0){r.i--;}
            } else //! Without else it could count r.i 2 times up.
                //! Ruckig waypoint finished.
                if(result==ruckig::Finished && r.maxvel_machine<0){
                    //std::cout<<"Msg.3 waypointvec i:"<<r.i<<" pos:"<<r.pos[0]<<" vel:"<<r.vel[0]<<" acc:"<<r.acc[0]<<" duration:"<<r.waypointvec.at(r.i).wp_duration<<std::endl;
                    if(r.i>0){r.i--;}
                }

    //! Final traject position reached.
    if(r.pos[0]>r.waypointvec.at(r.waypointvec.size()-1).endpos-0.001){
        r.at_finish=1;
        r.finished=1;
    }

    //! Begin traject position reached.
    if(r.pos[0]<r.waypointvec.at(0).startpos+0.001){
        r.at_start=1;
    }
    return 1;
}
