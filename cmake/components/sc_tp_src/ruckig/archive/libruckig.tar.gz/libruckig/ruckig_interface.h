#ifndef RUCKIG_INTERFACE_H
#define RUCKIG_INTERFACE_H

//! LibRuckig scurve lib
//! https://github.com/pantor/ruckig, extra info: https://github.com/pantor/ruckig/issues/64
//! Examples
//! https://docs.ruckig.com/pages.html
#include "libruckig/include/ruckig/ruckig.hpp"
#include "external_var.h"

//! Waypoint, (maxvel,maxacc,maxjerk,startpos,endpos,startvel,endvel,endacc)
struct WAYPOINT{
    //! Maxvel.
    double maxvel=0;
    //! Maxacc.
    double maxacc=0;
    //! Maxjerk.
    double maxjerk=0;
    //! Startpos.
    double startpos=0;
    //! Endpos.
    double endpos=0;
    //! Startvel. Used as endvel for negative feed.
    double startvel;
    //! Tarvel.
    double endvel=0;
    //! Pahtlenght
    double pathlenght=0;
    //! Waypoint duration.
    double wp_duration=0;
};

struct RUCKIG{
    //! Program status flags
    bool init=0;
    //! At path finish.
    bool at_finish=0;
    //! At path start.
    bool at_start=0;
    //! Start with demo values.
    bool demo=0;
    //! Waypoint counter.
    unsigned int i=0;

    //! Machine limits.
    double maxvel_machine=0;
    double maxacc_machine=0;
    double maxjerk_machine=0;
    //! Dofs velocity overide 20%.
    //! Velocity overide 0-20% may be a negative value.
    double maxvel_machine_overide=0;
    //! Adaptive feed -100% to 100%.
    double adaptive_feed=100;

    //! Controlled stop.
    bool motion_stop;
    //! Stop position snapshot.
    bool motion_stop_snapshot;
    double snapshot_pos=0;

    //! Pathlenght[i].
    double pathlenght;
    //! Distancetogo[i].
    double dtg;
    //! Traject duration.
    double tr_duration=0;
    //! Message reducer.
    double msg=0;
    //! Traject finished.
    bool finished=0;

    //! Waypoint vector
    std::vector<WAYPOINT> waypointvec;
};
extern std::vector<RUCKIG> rvec;

class ruckig_interface
{
public:
    ruckig_interface();

    void ruckig_example_0();
    void ruckig_example_1();

    int ruckig_traject(RUCKIG &r);
    int add_demo_waypoints(RUCKIG &r);
    int distancetogo(RUCKIG &r);
    int restart_at_waypoint(RUCKIG &r);

    //! Used by halmodule, joints
    DATA rm_ik(DATA *ptr);
    DATA rm_fk(DATA *ptr);

    double get_stop_distance(double curpos,double curvel,double curacc, double tarvel, double taracc, double maxacc, double maxjerk);
    std::pair<double, double> get_target_velocity_acceleration(double at_time, double curpos, double curvel, double curacc, double maxvel, double maxacc, double maxjerk);

    //! Ruckig data.
    ruckig::Result result;
    ruckig::Ruckig<1> otg {0.001};
    ruckig::InputParameter<1> in;
    ruckig::OutputParameter<1> out;
    std::array<double, 1> vel, acc, pos;

    //! A single Dofs.
    ruckig::Ruckig<1> otg0 {0.001};
    ruckig::InputParameter<1> in0;
    ruckig::OutputParameter<1> out0;
    std::array<double, 1> vel0, acc0, pos0;

    //! Used for get_stop_distance function.
    ruckig::Ruckig<1> otg1 {0.001};
    ruckig::InputParameter<1> in1;
    ruckig::OutputParameter<1> out1;
    std::array<double, 1> vel1, acc1, pos1;

};

#endif // RUCKIG_INTERFACE_H
