# ---
#
# Nothing to see here, as the Python version *always* uses dynamic number of degrees of freedom.
# 
# ---
