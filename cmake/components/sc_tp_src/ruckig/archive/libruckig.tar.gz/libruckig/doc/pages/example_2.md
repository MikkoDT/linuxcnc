## Example 2: Offline Trajectory Generation


### C++

\include 2_position_offline.cpp

### Python

\include 2_position_offline.py

### Output Trajectory

\image html 2_trajectory.png width=600px