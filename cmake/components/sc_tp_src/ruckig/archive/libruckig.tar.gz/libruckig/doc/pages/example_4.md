## Example 4: Online Waypoints Trajectory


### C++

\include 4_waypoints_online.cpp

### Python

\include 4_waypoints_online.py

### Output Trajectory

\image html 4_trajectory.png width=600px