## Example 7: Minimum Trajectory Duration


### C++

\include 7_minimum_duration.cpp

### Python

\include 7_minimum_duration.py

### Output Trajectory

\image html 7_trajectory.png width=600px