## Example 8: Dynamic Number of DoFs


### C++

\include 8_dynamic_dofs.cpp

### Python

\include 8_dynamic_dofs.py

### Output Trajectory

\image html 8_trajectory.png width=600px