## Example 1: Online Trajectory Generation


### C++

\include 1_position.cpp

### Python

\include 1_position.py

### Output Trajectory

\image html 1_trajectory.png width=600px