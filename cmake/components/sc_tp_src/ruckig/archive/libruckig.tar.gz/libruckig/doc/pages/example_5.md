## Example 5: Velocity Control


### C++

\include 5_velocity.cpp

### Python

\include 5_velocity.py

### Output Trajectory

\image html 5_trajectory.png width=600px