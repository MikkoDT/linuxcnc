## Example 6: Stop Trajectory


### C++

\include 6_stop.cpp

### Python

\include 6_stop.py

### Output Trajectory

\image html 6_trajectory.png width=600px