## Example 3: Waypoints Trajectory


### C++

\include 3_waypoints.cpp

### Python

\include 3_waypoints.py

### Output Trajectory

\image html 3_trajectory.png width=600px