/********************************************************************************
** Form generated from reading UI file 'ruckig_gui.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RUCKIG_GUI_H
#define UI_RUCKIG_GUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ruckig_gui
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout_6;
    QGridLayout *gridLayout_5;
    QLabel *label_20;
    QLabel *label_14;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_6;
    QLabel *label_11;
    QLabel *label_10;
    QLabel *label_13;
    QLabel *label_12;
    QLabel *label_19;
    QLabel *label_7;
    QLabel *label_4;
    QLineEdit *lineEdit_traject_vector_size;
    QLabel *label_21;
    QLabel *label_5;
    QLabel *label_17;
    QLabel *label_18;
    QLabel *label_22;
    QLabel *label_23;
    QLineEdit *lineEdit_current_line;
    QLineEdit *lineEdit_current_position;
    QLineEdit *lineEdit_current_velocity;
    QLineEdit *lineEdit_current_acceleration;
    QLineEdit *lineEdit_current_traject_duration;
    QLineEdit *lineEdit_current_path_duration;
    QLineEdit *lineEdit_pahtlenght;
    QLineEdit *lineEdit_path_start_position;
    QLineEdit *lineEdit_path_end_position;
    QLineEdit *lineEdit_path_start_velocity;
    QLineEdit *lineEdit_path_end_velocity;
    QLineEdit *lineEdit_path_max_velocity;
    QLineEdit *lineEdit_path_max_acceleration;
    QLineEdit *lineEdit_path_max_jerk;
    QLineEdit *lineEdit_distance_to_go;
    QLineEdit *lineEdit_at_traject_start;
    QLineEdit *lineEdit_at_traject_finish;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QDoubleSpinBox *doubleSpinBox_feed_override;
    QLabel *label_3;
    QLabel *label;
    QDoubleSpinBox *doubleSpinBox_machine_maxjerk;
    QLabel *label_2;
    QLabel *label_15;
    QDoubleSpinBox *doubleSpinBox_machine_maxacc;
    QDoubleSpinBox *doubleSpinBox_machine_maxvel;
    QPushButton *pushButton_motion_stop_resume;
    QSpacerItem *verticalSpacer;

    void setupUi(QMainWindow *ruckig_gui)
    {
        if (ruckig_gui->objectName().isEmpty())
            ruckig_gui->setObjectName(QString::fromUtf8("ruckig_gui"));
        ruckig_gui->resize(476, 549);
        QPalette palette;
        QBrush brush(QColor(194, 194, 194, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        QBrush brush1(QColor(33, 38, 45, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Button, brush1);
        QBrush brush2(QColor(255, 255, 255, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Text, brush2);
        QBrush brush3(QColor(184, 184, 184, 255));
        brush3.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::ButtonText, brush3);
        QBrush brush4(QColor(13, 17, 23, 255));
        brush4.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Base, brush4);
        palette.setBrush(QPalette::Active, QPalette::Window, brush4);
        QBrush brush5(QColor(56, 56, 56, 128));
        brush5.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Active, QPalette::PlaceholderText, brush5);
#endif
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Button, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Text, brush2);
        palette.setBrush(QPalette::Inactive, QPalette::ButtonText, brush3);
        palette.setBrush(QPalette::Inactive, QPalette::Base, brush4);
        palette.setBrush(QPalette::Inactive, QPalette::Window, brush4);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush5);
#endif
        QBrush brush6(QColor(190, 190, 190, 255));
        brush6.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::Button, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Text, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::ButtonText, brush6);
        palette.setBrush(QPalette::Disabled, QPalette::Base, brush4);
        palette.setBrush(QPalette::Disabled, QPalette::Window, brush4);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush5);
#endif
        ruckig_gui->setPalette(palette);
        ruckig_gui->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(ruckig_gui);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        gridLayout_6 = new QGridLayout(groupBox_3);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_5 = new QGridLayout();
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_20 = new QLabel(groupBox_3);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_5->addWidget(label_20, 10, 0, 1, 2);

        label_14 = new QLabel(groupBox_3);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_5->addWidget(label_14, 0, 4, 1, 1);

        label_8 = new QLabel(groupBox_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_5->addWidget(label_8, 3, 0, 1, 2);

        label_9 = new QLabel(groupBox_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        gridLayout_5->addWidget(label_9, 1, 0, 1, 2);

        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_5->addWidget(label_6, 6, 0, 1, 2);

        label_11 = new QLabel(groupBox_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));

        gridLayout_5->addWidget(label_11, 5, 0, 1, 2);

        label_10 = new QLabel(groupBox_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_5->addWidget(label_10, 4, 0, 1, 2);

        label_13 = new QLabel(groupBox_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));

        gridLayout_5->addWidget(label_13, 16, 0, 1, 2);

        label_12 = new QLabel(groupBox_3);
        label_12->setObjectName(QString::fromUtf8("label_12"));

        gridLayout_5->addWidget(label_12, 15, 0, 1, 2);

        label_19 = new QLabel(groupBox_3);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_5->addWidget(label_19, 9, 0, 1, 2);

        label_7 = new QLabel(groupBox_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_5->addWidget(label_7, 2, 0, 1, 2);

        label_4 = new QLabel(groupBox_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush2);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush6);
        label_4->setPalette(palette1);

        gridLayout_5->addWidget(label_4, 0, 0, 1, 2);

        lineEdit_traject_vector_size = new QLineEdit(groupBox_3);
        lineEdit_traject_vector_size->setObjectName(QString::fromUtf8("lineEdit_traject_vector_size"));

        gridLayout_5->addWidget(lineEdit_traject_vector_size, 0, 5, 1, 1);

        label_21 = new QLabel(groupBox_3);
        label_21->setObjectName(QString::fromUtf8("label_21"));

        gridLayout_5->addWidget(label_21, 11, 0, 1, 2);

        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_5->addWidget(label_5, 14, 0, 1, 2);

        label_17 = new QLabel(groupBox_3);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_5->addWidget(label_17, 7, 0, 1, 2);

        label_18 = new QLabel(groupBox_3);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_5->addWidget(label_18, 8, 0, 1, 2);

        label_22 = new QLabel(groupBox_3);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout_5->addWidget(label_22, 12, 0, 1, 2);

        label_23 = new QLabel(groupBox_3);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout_5->addWidget(label_23, 13, 0, 1, 2);

        lineEdit_current_line = new QLineEdit(groupBox_3);
        lineEdit_current_line->setObjectName(QString::fromUtf8("lineEdit_current_line"));

        gridLayout_5->addWidget(lineEdit_current_line, 0, 2, 1, 1);

        lineEdit_current_position = new QLineEdit(groupBox_3);
        lineEdit_current_position->setObjectName(QString::fromUtf8("lineEdit_current_position"));

        gridLayout_5->addWidget(lineEdit_current_position, 1, 2, 1, 4);

        lineEdit_current_velocity = new QLineEdit(groupBox_3);
        lineEdit_current_velocity->setObjectName(QString::fromUtf8("lineEdit_current_velocity"));

        gridLayout_5->addWidget(lineEdit_current_velocity, 2, 2, 1, 4);

        lineEdit_current_acceleration = new QLineEdit(groupBox_3);
        lineEdit_current_acceleration->setObjectName(QString::fromUtf8("lineEdit_current_acceleration"));

        gridLayout_5->addWidget(lineEdit_current_acceleration, 3, 2, 1, 4);

        lineEdit_current_traject_duration = new QLineEdit(groupBox_3);
        lineEdit_current_traject_duration->setObjectName(QString::fromUtf8("lineEdit_current_traject_duration"));

        gridLayout_5->addWidget(lineEdit_current_traject_duration, 4, 2, 1, 4);

        lineEdit_current_path_duration = new QLineEdit(groupBox_3);
        lineEdit_current_path_duration->setObjectName(QString::fromUtf8("lineEdit_current_path_duration"));

        gridLayout_5->addWidget(lineEdit_current_path_duration, 5, 2, 1, 4);

        lineEdit_pahtlenght = new QLineEdit(groupBox_3);
        lineEdit_pahtlenght->setObjectName(QString::fromUtf8("lineEdit_pahtlenght"));

        gridLayout_5->addWidget(lineEdit_pahtlenght, 6, 2, 1, 4);

        lineEdit_path_start_position = new QLineEdit(groupBox_3);
        lineEdit_path_start_position->setObjectName(QString::fromUtf8("lineEdit_path_start_position"));

        gridLayout_5->addWidget(lineEdit_path_start_position, 7, 2, 1, 4);

        lineEdit_path_end_position = new QLineEdit(groupBox_3);
        lineEdit_path_end_position->setObjectName(QString::fromUtf8("lineEdit_path_end_position"));

        gridLayout_5->addWidget(lineEdit_path_end_position, 8, 2, 1, 4);

        lineEdit_path_start_velocity = new QLineEdit(groupBox_3);
        lineEdit_path_start_velocity->setObjectName(QString::fromUtf8("lineEdit_path_start_velocity"));

        gridLayout_5->addWidget(lineEdit_path_start_velocity, 9, 2, 1, 4);

        lineEdit_path_end_velocity = new QLineEdit(groupBox_3);
        lineEdit_path_end_velocity->setObjectName(QString::fromUtf8("lineEdit_path_end_velocity"));

        gridLayout_5->addWidget(lineEdit_path_end_velocity, 10, 2, 1, 4);

        lineEdit_path_max_velocity = new QLineEdit(groupBox_3);
        lineEdit_path_max_velocity->setObjectName(QString::fromUtf8("lineEdit_path_max_velocity"));

        gridLayout_5->addWidget(lineEdit_path_max_velocity, 11, 2, 1, 4);

        lineEdit_path_max_acceleration = new QLineEdit(groupBox_3);
        lineEdit_path_max_acceleration->setObjectName(QString::fromUtf8("lineEdit_path_max_acceleration"));

        gridLayout_5->addWidget(lineEdit_path_max_acceleration, 12, 2, 1, 4);

        lineEdit_path_max_jerk = new QLineEdit(groupBox_3);
        lineEdit_path_max_jerk->setObjectName(QString::fromUtf8("lineEdit_path_max_jerk"));

        gridLayout_5->addWidget(lineEdit_path_max_jerk, 13, 2, 1, 4);

        lineEdit_distance_to_go = new QLineEdit(groupBox_3);
        lineEdit_distance_to_go->setObjectName(QString::fromUtf8("lineEdit_distance_to_go"));

        gridLayout_5->addWidget(lineEdit_distance_to_go, 14, 2, 1, 4);

        lineEdit_at_traject_start = new QLineEdit(groupBox_3);
        lineEdit_at_traject_start->setObjectName(QString::fromUtf8("lineEdit_at_traject_start"));

        gridLayout_5->addWidget(lineEdit_at_traject_start, 15, 2, 1, 4);

        lineEdit_at_traject_finish = new QLineEdit(groupBox_3);
        lineEdit_at_traject_finish->setObjectName(QString::fromUtf8("lineEdit_at_traject_finish"));

        gridLayout_5->addWidget(lineEdit_at_traject_finish, 16, 2, 1, 4);


        gridLayout_6->addLayout(gridLayout_5, 0, 0, 1, 1);


        gridLayout_3->addWidget(groupBox_3, 0, 0, 1, 1);

        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        gridLayout_2 = new QGridLayout(groupBox);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        doubleSpinBox_feed_override = new QDoubleSpinBox(groupBox);
        doubleSpinBox_feed_override->setObjectName(QString::fromUtf8("doubleSpinBox_feed_override"));
        doubleSpinBox_feed_override->setMaximum(20.000000000000000);

        gridLayout->addWidget(doubleSpinBox_feed_override, 3, 1, 1, 1);

        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 2, 0, 1, 1);

        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        doubleSpinBox_machine_maxjerk = new QDoubleSpinBox(groupBox);
        doubleSpinBox_machine_maxjerk->setObjectName(QString::fromUtf8("doubleSpinBox_machine_maxjerk"));
        doubleSpinBox_machine_maxjerk->setMaximum(10000.000000000000000);
        doubleSpinBox_machine_maxjerk->setValue(0.000000000000000);

        gridLayout->addWidget(doubleSpinBox_machine_maxjerk, 2, 1, 1, 1);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        label_15 = new QLabel(groupBox);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout->addWidget(label_15, 3, 0, 1, 1);

        doubleSpinBox_machine_maxacc = new QDoubleSpinBox(groupBox);
        doubleSpinBox_machine_maxacc->setObjectName(QString::fromUtf8("doubleSpinBox_machine_maxacc"));
        doubleSpinBox_machine_maxacc->setMaximum(10000.000000000000000);
        doubleSpinBox_machine_maxacc->setValue(0.000000000000000);

        gridLayout->addWidget(doubleSpinBox_machine_maxacc, 1, 1, 1, 1);

        doubleSpinBox_machine_maxvel = new QDoubleSpinBox(groupBox);
        doubleSpinBox_machine_maxvel->setObjectName(QString::fromUtf8("doubleSpinBox_machine_maxvel"));
        doubleSpinBox_machine_maxvel->setMinimum(-10000.000000000000000);
        doubleSpinBox_machine_maxvel->setMaximum(10000.000000000000000);
        doubleSpinBox_machine_maxvel->setValue(0.000000000000000);

        gridLayout->addWidget(doubleSpinBox_machine_maxvel, 0, 1, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);

        pushButton_motion_stop_resume = new QPushButton(groupBox);
        pushButton_motion_stop_resume->setObjectName(QString::fromUtf8("pushButton_motion_stop_resume"));

        gridLayout_2->addWidget(pushButton_motion_stop_resume, 1, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_2->addItem(verticalSpacer, 2, 0, 1, 1);


        gridLayout_3->addWidget(groupBox, 0, 1, 1, 1);

        ruckig_gui->setCentralWidget(centralwidget);

        retranslateUi(ruckig_gui);

        QMetaObject::connectSlotsByName(ruckig_gui);
    } // setupUi

    void retranslateUi(QMainWindow *ruckig_gui)
    {
        ruckig_gui->setWindowTitle(QCoreApplication::translate("ruckig_gui", "ruckig_gui", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("ruckig_gui", "Traject ", nullptr));
        label_20->setText(QCoreApplication::translate("ruckig_gui", "Path end velocity", nullptr));
        label_14->setText(QCoreApplication::translate("ruckig_gui", "of", nullptr));
        label_8->setText(QCoreApplication::translate("ruckig_gui", "Acceleration", nullptr));
        label_9->setText(QCoreApplication::translate("ruckig_gui", "Position", nullptr));
        label_6->setText(QCoreApplication::translate("ruckig_gui", "Pathlenght", nullptr));
        label_11->setText(QCoreApplication::translate("ruckig_gui", "Path duration", nullptr));
        label_10->setText(QCoreApplication::translate("ruckig_gui", "Traject duration", nullptr));
        label_13->setText(QCoreApplication::translate("ruckig_gui", "at traject finish", nullptr));
        label_12->setText(QCoreApplication::translate("ruckig_gui", "at traject start", nullptr));
        label_19->setText(QCoreApplication::translate("ruckig_gui", "Path start velocity", nullptr));
        label_7->setText(QCoreApplication::translate("ruckig_gui", "Velocity", nullptr));
        label_4->setText(QCoreApplication::translate("ruckig_gui", "Line i", nullptr));
        lineEdit_traject_vector_size->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        label_21->setText(QCoreApplication::translate("ruckig_gui", "Path max velocity", nullptr));
        label_5->setText(QCoreApplication::translate("ruckig_gui", "Distance to go Dtg", nullptr));
        label_17->setText(QCoreApplication::translate("ruckig_gui", "Path start position", nullptr));
        label_18->setText(QCoreApplication::translate("ruckig_gui", "Path end position", nullptr));
        label_22->setText(QCoreApplication::translate("ruckig_gui", "Path max acceleration", nullptr));
        label_23->setText(QCoreApplication::translate("ruckig_gui", "Path max jerk", nullptr));
        lineEdit_current_line->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_current_position->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_current_velocity->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_current_acceleration->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_current_traject_duration->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_current_path_duration->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_pahtlenght->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_start_position->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_end_position->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_start_velocity->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_end_velocity->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_max_velocity->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_max_acceleration->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_path_max_jerk->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_distance_to_go->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_at_traject_start->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        lineEdit_at_traject_finish->setText(QCoreApplication::translate("ruckig_gui", "0", nullptr));
        groupBox->setTitle(QCoreApplication::translate("ruckig_gui", "Machine", nullptr));
        label_3->setText(QCoreApplication::translate("ruckig_gui", "Maxjerk", nullptr));
        label->setText(QCoreApplication::translate("ruckig_gui", "Maxvel", nullptr));
        label_2->setText(QCoreApplication::translate("ruckig_gui", "Maxacc", nullptr));
        label_15->setText(QCoreApplication::translate("ruckig_gui", "Feed overide", nullptr));
        pushButton_motion_stop_resume->setText(QCoreApplication::translate("ruckig_gui", "Motion stop - resume", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ruckig_gui: public Ui_ruckig_gui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RUCKIG_GUI_H
